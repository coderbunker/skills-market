module.exports = {
	"skills": {
		"skills" : [
			{
				"hash" : 6145243,
				"name" : "testname",
				"demand hours" : 3,
				"spend hours" : 1
			},
			{
				"hash" : 7132541,
				"name" : "thimo",
				"demand hours" : 8,
				"spend hours" : 3
			}
		],
		"org" : "testorg"
	}
}