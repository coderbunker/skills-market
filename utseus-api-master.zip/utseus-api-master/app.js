var express = require('express');
var app = express();

const debug = require('debug')('utseus-api')

const config = require('./config.js');
const mock = require('./mock.js');

const register = require('./controllers/register.js');
const mentoring = require('./controllers/mentoring.js');

const API_V1_PREFIX = '/api/v1';

app.get(API_V1_PREFIX + '/skills', function (req, res) {
	res.send(mock.skills);
})

app.post(API_V1_PREFIX + '/help', function (req, res) {
	res.send();
})

app.get(API_V1_PREFIX + '/mentoring/:mentor/:mentee', function (req, res) {
	const mentor = req.params.mentor;
	const mentee = req.params.mentee;
	mentoring(mentor, mentee).then(function({status, message}){
		res.status(status).send(message);
	});
})

app.post(API_V1_PREFIX + '/register/:member', function (req, res) {
	const member = req.params.member;
	register(member).then(function({status, message}){
		res.status(status).send(message);
	});
})

app.listen(config.port, () => {
	debug('App started at port %d', config.port);
})
