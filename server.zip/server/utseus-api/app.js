var express = require('express');
var app = express();

const debug = require('debug')('utseus-api')
const organisation = "Organisation";
const cost = 10;

const cors = require('cors');
const config = require('./config.js');
const mock = require('./mock.js');
const http = require('./http.js');
const dataset = require('./dataset.js');
const Promise = require('promise');

const register = require('./controllers/register.js');
const mentoring = require('./controllers/mentoring.js');

const API_V1_PREFIX = '/api/v1';

app.use(cors());

String.prototype.hashCode = function() {
    var hash = 0;
    if (this.length == 0) {
        return hash;
    }
    for (var i = 0; i < this.length; i++) {
        char = this.charCodeAt(i);
        hash = ((hash<<5)-hash) + char;
        hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
}

app.get(API_V1_PREFIX + '/users', function (req, res) {
	console.log("w3", "request users");
	console.log("w3", getUsers());
	var json = getUsers();
	res.status(http.SUCCESS).json(json);
});

app.get(API_V1_PREFIX + '/queue', function (req, res) {
	// TODO add person to queue on ask for help
	// TODO remove person from queue on certify
	// TODO return list of waiting for help in queue
	// person, skill, time
	res.send(getWaitingQueue());
})

app.get(API_V1_PREFIX + '/skills', function (req, res) {
	res.send(dataset.skills);
})

app.post(API_V1_PREFIX + '/help/:mentee/:skill/:time', function (req, res) {
	// TODO validate there is such profile
	const profileName = req.params.mentee;
	const skill = req.params.skill;
	const time = req.params.time;
	askForHelpFunc(profileName, organisation, skill, time).then(function({status, message}) {
		res.status(status).send(message);
	});
	
	// TODO wait for receipt
})

app.post(API_V1_PREFIX + '/mentoring/:mentor/:mentee/:skill/:time', function (req, res) {
	const mentor = req.params.mentor;
	const mentee = req.params.mentee;
	const skill = req.params.skill;
	const time = req.params.time;
	certifyFunc(mentor, mentee, skill, time).then(function({status, message}) {
		res.status(status).send(message);
	});
	// TODO wait for receipt
})

app.get(API_V1_PREFIX + '/dashboard', function (req, res) {
	console.log("w3", "request dashboard");
	console.log("w3", "History: " + getHistory());
	var json = JSON.parse(getHistory());
	res.status(http.SUCCESS).json(json);
});

app.post(API_V1_PREFIX + '/register/:member/:skill', function (req, res) {
	const member = req.params.member;
	const skill = req.params.skill;
	registerMemberWithSkill(member, skill).then(function({status, message}){
		res.status(status).send(message);
	});
})

function registerMemberWithSkill(member, skill) {
	return new Promise(function(fulfill) {
		createCertificate(member, skill, organisation);
		fulfill({
			status: http.SUCCESS,
			message: 'user was successfully registered'
		}); 
	});
}

app.listen(config.port, () => {
	debug('App started at port %d', config.port);
})

// regiom controller functions

function askForHelpFunc(profileName, organisation, skill, time, cost) {
	return new Promise(function(fulfill){
		askForHelp(profileName, organisation, skill, time, time * cost);
		fulfill({
			status: http.SUCCESS,
			message: 'request for help was successfully registered'
		}); 
		trackHistory(profileName, organisation, skill, time);
		// TODO process negative scenario
	});
}

function certifyFunc(mentor, mentee, skill, time) {
	return new Promise(function(fulfill) {
		if (!(mentor in profiles) || !(mentee in profiles)) {
			fulfill({
				status: http.BAD_REQUEST,
				message: 'Either mentor or mentee params is not valid'
			});
		} else {
			var mentorAccount = getAccountByName(mentor);
			var menteeAccount = getAccountByName(mentee);
			console.log("w3", "certifyFunc");
			console.log("w3", skill);
			certify(mentorAccount, menteeAccount, skill, time, cost);
			fulfill({
				status: http.SUCCESS,
				message: 'User was certified'
			});
			trackHistory(mentor, mentee, skill, time);
			markedRequestAsProcessedInWaitingQueue(mentee, organisation, skill, time);
			// TODO process negative scenario - no certification on blockchain
		}
	});
}

// endregion

// region runtime storage

var profiles = {
	'lawlietyumiao' : '0x73bb2520a2c132de287dff9cb25c88cda33f603f',
	'mickaeliccardi' : '0x719c437486058a77bb91b120ef7f75df7b557ca2',
	'13661429541' : '0xb459ad6efd57b47f129c2473bc987d5b4186697d',
	'18800205323' : '0x77beace7a153ff1cc6d64ebb2a2647efe05b7b22',
	'Time20131104' : '0x00d044179ddd814da416863b082dc2e092b9a382',
	'Sdonkey27' : '0x8f0dde8bff40584fad44a9e28acd7a47ff3874d2',
	'13162112280' : '0xb21db97998af68e62f99ccfcbaa55bc19753fd5a',
	'13701627536' : '0xb36083362e007e9191c085c7eff5d3f0224dd310',
	'Christophelzy' : '0x2dcb9025c48052e9292ca1cdf2f837191c1e38bc',
	'maxlecle' : '0xea14694a4db8c8e60aed8e79826e6fe820591cbf',
	'tth_truong' : '0x5239aedf4f368cc3cbb7cea2ac9adf7e0838e6b1',
	'louis_den' : '0xe999b49c7c8a736ad19255680d3f9ff25c19b3be',
	'Alidaoudi' : '0xd021bd7c1d7c3152f6556e4cea56dd4df4c4955c',
	'charlotte_lamouche' : '0xa583efc3e681e6a3825a6ef7b7639cdfcd011101',
	'sylvainmafr' : '0x366353078f9afd685735cc06e08eb8159f68e797',
	'Krystot' : '0x8feefdac880b9af0cc8cc759c2da6bebcbda96ce',
	'a73648274' : '0x126b535b30d51ccd8208b654223c3f5ffed478e6',
	'None' : '0xbc6dc1790c518753d8d676c01a40dcb870228cff',
	'tonyungawa' : '0x793681b974da09d53f1de8dabbcfc2aa1c887966',
	'corentin-9578' : '0xa98f6a3a3f4d6cb8c1c1a9074b15872963b20890',
	'Victor-_-_-_-_-' : '0x78d2594733ae521fca1e59320b496de12f792df2',
	'AmouravecungrandA' : '0x948b95d12907b2609bef20504d7e61da13a8d2df',
	'Eline-migeon' : '0xba7e5749ed037064825e78681f899a6e20710ae8',
	'Mathildebuchta' : '0xf49726295f2ce0f421cc8eb1ff2414f86e7a4191',
	'lpqweixin00' : '0x20829b395995fd924d48670e8579f0623483e80e',
	'owusuhelene' : '0x07dc8dd4f74f2b6d7070787254ddda15a9c725ba', 
	'AshhBashh' : '0x73525189500208143579b4d68371250dec8a344c', 
	'ClaraPerez0510' : '0xf1d94b0ddfb79034414a70fe271003cbe726073c',
	'clara_gruszewski' : '0x8fd19dccd97d90ad8e4b44e7735440f521d9b6af',
	'18702111896' : '0x47b79de8dccb088be8b64a787deae08b2ad07c62',
	'ItalianGuy94' : '0x47b79de8dccb088be8b64a787deae08b2ad07c62',
	'837299906' : '0x47b79de8dccb088be8b64a787deae08b2ad07c62',
	'18717982760' : '0xe1592f2f7dbfd00092ec993887c12987c6f6db40',
	'Bougetmaxime' : '0x8997eb69cdec59fe5be1c3156978d1ec600e2fe7',
	'Octavedescours' : '0x5e65ce4f5f462a6bb3fb7feeb134d8811f0d3660',
	'zsdyyt' : '0x0723d5046c292bfd9810a32632632954190a054e',
	'Catherine_0504' : '0x6a0c6f1ad2437b3ef81c67b7b93daba0c2024e59',
	'gsplwxx' : '0x5476f2b6507400faeafeafbb389318d641f78c83',
	'sm_sunny' : '0x200e8765370f86f2933ae41286119245b4ab790a',
	'PandaBadiste78' : '0x78a524a739906b056ce9598eccd8821324e60150', 
	'cj879c28ac' : '0xd7c6a43dc6201bfd754c4a11a4f65e36208063d6',
	'babsae' : '0x8918640bc5edc4a40fbf6d22dd54a5234037dac4',
	'helloSimonhe' : '0x1b15d98154c9579c955cb006daa7298c9d210986',
	'artinesmail' : '0xe32547ca8bc51f09d2afb2304ea7bf78a7d367b8',
	'vincentlora' : '0x587dc33fca4ff90fe0e54f7efc2316d5439839cd', 
	'tangyeqingliu' : '0x675ed1a2ae345d60ca0a9160f2931dcbe9ca8692'
}

// endregion

process.stdout.write("starting web3..");

// region initiate Web3

var Web3 = require('web3');
var web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545')); 
console.info('w3', web3.eth.accounts);

// endregion

// region deploy the contract

let fs = require("fs");
let source = fs.readFileSync("SkillsMarket.js");
console.info('w3', source);
let contracts = JSON.parse(source)["contracts"];
console.info('w3', contracts);

var skillsMarketAbi = web3.eth.contract(JSON.parse(contracts['SkillsMarket.sol:SkillsMarket'].abi));
var skillsMarketBin = "0x" + contracts['SkillsMarket.sol:SkillsMarket'].bin;

console.info('w3', skillsMarketAbi);
console.info('w3', "=== ==== ===");
console.info('w3', skillsMarketBin);

// endregion

// region init the contract

var deployTransitionObject = {from: web3.eth.accounts[0], data: skillsMarketBin, gas: 2000000};
let skillsMarketContract = skillsMarketAbi.new(deployTransitionObject);

const receipt = web3.eth.getTransactionReceipt(skillsMarketContract.transactionHash);

console.info('w3', receipt);
console.info('w3', receipt.contractAddress);

const SkillsMarket = skillsMarketAbi.at(receipt.contractAddress);

// endregion

// region create an certificate

console.info('w3', "create accounts");

// createCertificate("lawlietyumiao", "React", organisation);
// createCertificate("mickaeliccardi", "Python", organisation);

console.info('w3', "finish with creating accounts");

function createCertificate(profileName, skill, organization) {
	// TODO obtain data 
	// registerMemberSkills(address member, uint hashKey, bytes32 skill, uint spendHours, uint demandHours)
	var account = getAccountByName(profileName);
	var hashKey = (String(skill) + String(organization)).hashCode(); // TODO generate hashKey based on org and skill name
	var skillInBytes = web3.fromAscii(skill); // TODO convert skill string into bytes32
	var spendHours = 100; // optional
	var demandHours = 100; // optional

	console.log("w3", "Account: " + account);

	SkillsMarket.registerMemberSkills.sendTransaction(
		account,
		hashKey,
		skillInBytes, 
		spendHours, 
		demandHours,
		{from: account, gas: 300000}
	);
	
	// console.log("w3", "RegisterMemberSkills: ");
	
	// TODO wait till it would be executed on blockchain
	// TODO get a status and return back to the client
	const skillsLength = SkillsMarket.getSkillForMember(account);
	console.log("w3", "Amount of skills: " + skillsLength);
}

// endregion

// region ask for help
 
function askForHelp(profileName, organisation, skill, time, cost) {
	console.log("w3", "[start] askForHelp");
	var account = getAccountByName(profileName);
	var hashKey = (String(skill) + String(organisation)).hashCode();
	var skillInBytes = web3.fromAscii(skill);
	console.log("w3", "HashKey: " + hashKey);
	const status = SkillsMarket.askForHelp.sendTransaction(
		hashKey,
		account,
		skillInBytes,
		time,
		cost,
		{from: account, gas: 300000, value: cost}
	);
	console.log("w3", "Status: " + status);
	// console.log("w3", "Status: " + web3.eth.getRawTransaction(status));
	const count = SkillsMarket.getAmountOfPeopleWaitingForHelp(hashKey);
	addToWaitingQueue(profileName, organisation, skill, time);
	console.log("w3", "Amount of people waiting for help: " + count);
	console.log("w3", "[end] askForHelp");
}

var skillRequestEvent = SkillsMarket.SkillRequest();
skillRequestEvent.watch(function(error, result) {
	if (error) {
		console.log("error: " + error);
	} else {
		console.log("result: " + result);
	}
});

// endregion

// region certify

function certify(mentorAccount, menteeAccount, skill, time) {
	console.log("w3", "[start] certify");
	var hashKey = (String(skill) + String(organisation)).hashCode();
	console.log("w3", "HashKey: " + hashKey);
	console.log("w3", "Mentor: " + mentorAccount + "\n");
	console.log("w3", "Mentee: " + menteeAccount + "\n");
	console.log("w3", "hashKey: " + hashKey + "\n");
	console.log("w3", "Time: " + time + "\n");
	const status = SkillsMarket.certify.sendTransaction(
		mentorAccount, 
		menteeAccount, 
		hashKey, 
		time, 
		time * cost,
		{from: mentorAccount, gas: 3000000});
		// .catch(error => console.log("Error: " + error));
	
	console.log("w3", status);
	console.log("w3", "[end] certify");
}

var mentorCertificationEvent = SkillsMarket.MentorCertification();
mentorCertificationEvent.watch(function(error, result) {
	if (error) {
		console.log("w3", "Mentor certify error: " + error);
	} else {
		console.log("w3", "Mentor certify result: " + result);
		console.log("w3", "Mentor certify result: " 
			+ result.mentor 
			+ " " 
			+ result.mentee);
	}
});

// endregion

// region Debug

var debugEventListener = SkillsMarket.Debug();
debugEventListener.watch(function(error, result) {
	if (error) {
		console.log("w3", "Debug error: " + error);
	} else {
		console.log("w3", "Debug: " + result.code);
	}
})

// endregion

// region transactions history

var history = [];

function trackHistory(from, to, skill, time) {
	var item = { "from" : from, "to" : to, "skill" : skill, "time" : time};
	console.log("w3", item);
	history.push(JSON.stringify(item));
	console.log("w3", "history size: " + history.length);
} 

function getHistory() {
	console.log(history);
	return "[" + history + "]";
}

function getNameByAccount(account) {
	return getKeyByValue(profiles, account);
}

// endregion

// region waiting queue 

var waitingQueue = [];

function getWaitingQueue() {
	console.log(transformQueueIntoJson());
	return transformQueueIntoJson();
}

function addToWaitingQueue(person, organisation, skill, time) {
	console.log("w3", "=====================");
	console.log("w3", "=====================");
	var item = { "person" : person, "skill" : skill, "time" : time, "mentored" : false};
	console.log("w3", "addToWaitingQueue");
	console.log("w3", item);
	waitingQueue.push(item);
	console.log("w3", "queue size: " + waitingQueue.length);
}

/**
 * conditions:
 * - one person -> one skill
 * - one person -> two skills
 * - one person -> skill (which is just completed) and the same person who ask for help again
 * 
 * solution:
 * - hold all data
 * - add boolean parameter as indicator of processed
 * - iterate over array to find righ tuple<person, skill>
 * - provide decorator whoch convert array of data into json format
 * */ 

function markedRequestAsProcessedInWaitingQueue(person, organisation, skill, time) {
	var size = waitingQueue.length;
	console.log("w3", "=====================");
	console.log("w3", "markedRequestAsProcessedInWaitingQueue");
	for (var idx = 0; idx < size; idx++) {
		console.log("w3", 
			"person: " + waitingQueue[idx].person + " " +
			"skill: " + waitingQueue[idx].skill + " " + 
			"mentored: " + waitingQueue[idx].mentored + " "
		);
		console.log("w3", 
			"person: " + person + " " +
			"skill: " + skill + " " 
		);
		if (waitingQueue[idx].person === person 
			&& waitingQueue[idx].skill === skill
			&& waitingQueue[idx].mentored === false) {
			
			console.log("w3", "waitingQueue[idx].mentored");
			waitingQueue[idx].mentored = true;
		}
	}
}

function transformQueueIntoJson() {
	var result = [];
	var size = waitingQueue.length;
	for (var idx = 0; idx < size; idx++) {
		result.push(JSON.stringify(waitingQueue[idx]));
	}
	return "[" + result + "]";
}

// endregion

// region users

function getUsers() {
	return dataset.users;
}

// endregion

// region helpers

function getAccountByName(key) {
    var account;
    Object.keys(profiles).find(key => account = profiles[key]);
    return account;
}

function getKeyByValue(object, value) {
	return Object.keys(object).find(key => object[key] === value);
}

// endregion