module.exports = {
	'SUCCESS': 200,
	'BAD_REQUEST': 400
}